# RAWDOG 1.0.0 website verification

Local browser checks on 2026-09-28 used the actual static site beneath `/RAWDOG/` in the Codex browser. Search by AR Sco and candidate source name passed; numeric distance sorting in both directions kept all unselected values last. Magnetic-CV plus inferred/proposed host filters returned ASKAP J174508.9-505149 with both classification labels. Marginal-radio filtering retained all five systems including Hya 1 and VV Pup. Source detail inspection verified AR Sco's distinct region/polar fields, MCSE wording and retained alternatives, and CHIME's unresolved host/no assigned Gaia counterpart. Clicking an AR Sco sky symbol opened the correct source hash/detail. SVG titles expose source names, classes, hosts and CMD/astrometry qualifications.

Opt-in filtering with zero search matches produced 0/58 sky and 0/56 CMD plotted counts; visual inspection showed no foreground symbols or uncertainty segments. Background density remained fixed. Independent code review caught and corrected residual uncertainty segments under filtering before publication. Full figures remain versioned downloads.

Responsive browser check at 390×844: stacked controls/figures and mobile source dialog were usable, with no page-wide horizontal overflow; only the large catalog table scrolls within its bounded container. Desktop figure/website screenshots were visually checked, including title separation and brighter-upward CMD layout. No browser error/warning messages were reported.

Browser filtered CSV downloaded to disk with one ASKAP row; every field matched the versioned full summary exactly, including the exact Gaia ID. Downloaded sky PDF and CMD SVG matched local versioned SHA-256 hashes. All 20 static HTML-relative assets/document/data links and all 58 source bundles returned HTTP 200 beneath the project prefix. Versioned archive and checksums are generated with `scripts/package.py`.

GitHub Pages deployed successfully from public repository PSR-Jake/RAWDOG, main branch/root, at https://psr-jake.github.io/RAWDOG/. Initial Pages workflow 36409121244 completed successfully. Live browser rendering showed all 58 systems; exact Gaia-ID search returned AR Sco without precision loss. QS Vir source detail loaded all 10 observation rows, 141 measurement records, geometric posterior bounds and references. The live AR Sco evidence JSON retained MCSE wording.

Live HTTP downloads of the index, catalog JSON, versioned summary, both plot-input tables, sky PDF, CMD SVG and complete archive returned HTTP 200 and matched validated local bytes exactly. The final documentation/archive update is also verified after deployment. Reference-manifest reachability checks are historical RC3 checks; external paper links were not all newly requested.

## Website/figure revision web r1 — 2026-09-29

Catalog version remains 1.0.0. The public scientific check and new `scripts/lpt_comparison.py` check passed: all 56 foreground photometry/distance evidence joins, four placements of two existing members, unchanged main Gaia inputs, nonlinear magnitude endpoints, retained ILT alternatives, unique SVG IDs and source/token links on every foreground point, bound, color segment and label. The RC3 regression and temporary release exporter/validation were rerun successfully; all ten RC3 CSVs reproduced byte-for-byte. SHA-256 comparison preserved 89 protected files, including historical RC packages, audited masters, public 1.0.0 tables, original figures and archive.

Local browser checks beneath `/RAWDOG/` passed: exact Gaia-ID search, distance sorting both ways with missing values last, five marginal-signal systems, four overlapping LPT members, concise GLEAM-X/ILT/AR Sco overviews, closed methods/alternatives/reference disclosures and full observation metadata. AR Sco retains separate region/polar fields and MCSE wording. CHIME has no empty property cards or assumed Gaia/WD quantities. A comparison SED symbol opened the correct ILT source. SVG hover/accessibility descriptions retain source and method qualifications. Opt-in LPT filtering gave 4/58 sky, 2/56 CMD and 2/2 comparison systems; zero matches visibly removed all comparison foreground symbols, intervals, connectors and source/method labels. A single ILT match retained its two method symbols and bounds only.

At the default desktop viewport, the sky SVG occupies 1177.6 px, exactly its content width; the CMD/comparison are limited to 1000 px. Desktop figures and the 390×844 mobile comparison, controls and CHIME source dialog were visually checked. Mobile document width equals viewport width (390 px), with the catalog table bounded separately. Viewport override was reset. No browser warning/error logs were reported.

The browser-downloaded comparison CSV matches validated local bytes exactly. The actual filtered-export function was executed with the current ILT row: all fields match the immutable summary, including the exact Gaia identifier and unrounded numerical values. The in-app browser did not deliver a completion event/file for the generated Blob download in this revision; its button was exercised, but that browser-specific save path is not claimed as newly verified. Static download links are checked separately.


GitHub Pages revision deployment 36510941972 completed successfully for commit ed562878a701bd70d4bb2371372bf49f5f85f1b2. The live browser showed the exact name expansion, GLEAM-X concise overview/prior warning, expandable complete references and both LPT method placements. Live browser-downloaded comparison CSV and PDF matched current local bytes. Fourteen representative live assets/downloads (including the original archive/figure, unchanged main inputs, new comparison/checksums and revised sky/CMD figures) returned HTTP 200 and matched local bytes exactly. No live browser warning/error logs were reported.


## Website revision web r2 — 2026-09-29

Author feedback removed the embedded LPT comparison from the main page; the historical comparison products, inputs and audit are retained in a named download disclosure. Local browser verification found exactly two embedded plots, the clarified sortable “Radio observations” heading with its count tooltip, functioning keyboard sorting, and zero-match opt-in sky/CMD counts without any missing-element errors. Supplementary downloads remain accessible after expanding their disclosure. JavaScript syntax and the existing scientific check passed; scientific inputs and figure products are unchanged.

## Website revision web r3 — 2026-09-30

JavaScript syntax and `node scripts/check_presentation.js` passed: symmetric/asymmetric offsets, scientific notation, zero values/errors, unreported error sides, endpoint-only intervals, HTML escaping, all 58 unchanged source summaries, AR Sco MCSE/component fields and retained host filter. The existing scientific check passed (58 sky, 56 CMD; all membership, evidence, formula and coordinate checks). SHA-256 checks preserved 89 historical/public/master files and every web-r1 scientific product. No catalog export or scientific figure was regenerated.

The actual local browser verified the dog/star header logo, removal of the subtitle and WD-host table column, exact Gaia-ID search, numeric distance sorting both ways, the unresolved-host filter and CHIME's candidate/exclusion detail. AE Aqr's stacked +0.12/−0.13 pc offsets, symmetric mass error and orbital-period exponent were visually checked. A 390×844 browser check found usable stacked property cards, the spoken asymmetric-offset label and a readable logo/navigation, with document width below viewport width. The temporary viewport override was reset. Zero-match opt-in filtering reported 0/58 sky and 0/56 CMD. No browser warning/error messages were reported. Display formatting does not mutate catalog values; full metadata and downloads retain original precision and conventions.

## Website revision web r4 — 2026-09-30

The presentation check now covers two-decimal formatting, trailing zeros, real zero and missing values, and the closed additional-downloads disclosure. JavaScript syntax and the scientific check passed. All 89 protected files and every web-r1 scientific product retained their SHA-256 hashes.

Local browser checks beneath `/RAWDOG/` verified AE Aqr 9.88 h / 91.34 pc, other rounded rows and missing-value dashes; distance sorting in both directions still uses raw values. The default download section exposes five common links. Keyboard expansion reveals all eight additional CSV tables and audit documentation; it collapses again correctly. Desktop and 390×844 mobile screenshots were visually checked, with wrapped download links and no page-wide overflow. Viewport override was reset and no warning/error logs were reported. Catalog data, source details, exports, plot inputs and figure products are unchanged.


## Catalogue addition 1.0.1 / web r5 — 2026-09-30

Scientific and presentation checks pass for 59 systems, 97 observations, 7,292 evidence records and 669 references. Local browser search for ASKAP J1448 returns the added source; its dialog displays the established CV host, qualified polar/bouncer interpretation, distinct orbital and recurrence clocks, explicit CMD exclusion, 109 evidence records, five review issues and both references. The full map has 59 systems and the CMD 56 with three exclusions. Versioned catalogue/source requests avoid stale browser caches. Historical data, source bundles, figures and archive are checked byte-for-byte against the preceding commit.
